﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chinook.Report.Marketing.Models
{
    class ArtistStatistic
    {
    }
}
