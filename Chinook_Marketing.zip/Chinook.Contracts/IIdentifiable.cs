﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chinook.Contracts
{
    public interface IIdentifiable
    {
        int Id { get; set; }
    }
}
