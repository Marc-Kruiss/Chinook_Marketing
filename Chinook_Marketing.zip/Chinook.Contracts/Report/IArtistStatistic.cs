﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chinook.Contracts.Report
{
    interface IArtistStatistic
    {
        public string Name { get;}
        public int AlbumCount { get;}
    }
}
